rootProject.name = "notification-service"
